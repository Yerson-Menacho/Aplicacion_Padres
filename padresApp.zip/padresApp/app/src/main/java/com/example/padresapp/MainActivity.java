package com.example.padresapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.padresapp.BD.bdUsuario;

public class MainActivity extends AppCompatActivity {

    EditText Email, password;
    Button btnlogin, btnRegistrar;
    bdUsuario BD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Email = findViewById(R.id.txtEmail);
        password = findViewById(R.id.txtPass);
        btnlogin = findViewById(R.id.btnLogin);
        btnRegistrar = findViewById(R.id.btnIrRegistrar);

        // Inicialización de la base de datos
        BD = new bdUsuario(this);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = Email.getText().toString();
                String pass = password.getText().toString();

                if(user.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Por favor ingrese todos los campos", Toast.LENGTH_SHORT).show();
                } else {
                    // Verificar si BD es nulo antes de usarlo
                    if (BD != null) {
                        Boolean comprobarUserPass = BD.CompromarEmailPass(user, pass);
                        if (comprobarUserPass) {
                            Toast.makeText(MainActivity.this, "Sesión iniciada", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), Principal.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivity.this, "Credencial no válida", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // Manejar el caso donde BD es nulo
                        Toast.makeText(MainActivity.this, "Error de base de datos", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
