package com.example.padresapp.BD;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;

import net.jpountz.lz4.LZ4FrameOutputStream;

public class bdUsuario extends SQLiteOpenHelper{

    public static final String BDNAME = "Login.bd";

    public bdUsuario(Context context){
        super (context, "login.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyBD) {
        MyBD.execSQL("create table Usuario(Email TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyBD, int oldVersion, int newVersion) {
        MyBD.execSQL("drop table if exists Usuario");
    }

    public Boolean insertData(String Email, String password){
        SQLiteDatabase MyBD = this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("Email", Email);
        contentValues.put("password", password);
        long result = MyBD.insert("Usuario", null, contentValues);
        if(result == -1) return  false;
        else return  true;
    }

    public Boolean ComprobarEmail(String Email){
        SQLiteDatabase MyBD = this.getWritableDatabase();
        Cursor cursor = MyBD.rawQuery("Select * from Usuario where Email = ?", new String[]{Email});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }

    public Boolean CompromarEmailPass(String Email, String password){
        SQLiteDatabase MyBD = this.getWritableDatabase();
        Cursor cursor = MyBD.rawQuery("Select * from Usuario where Email = ? and password =?", new String[]{Email, password});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }
}
