package com.example.padresapp;

public interface iComunicaFragments {
}
