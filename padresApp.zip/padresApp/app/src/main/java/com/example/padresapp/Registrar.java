package com.example.padresapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.padresapp.BD.bdUsuario;

public class Registrar extends AppCompatActivity {

    //Variable login
    EditText Nombre, Email, password, repetpass;
    Button btnCancelar, btnRegistra;
    bdUsuario BD;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registro);

        //validacion de boton login
        Nombre=(EditText)findViewById(R.id.txtNombreReg);
        Email=(EditText)findViewById(R.id.txtEmailReg);
        password=(EditText)findViewById(R.id.txtRepPass);
        repetpass=(EditText)findViewById(R.id.txtRepPass);
        btnRegistra=(Button)findViewById(R.id.btnRegistrar);
        btnCancelar=(Button)findViewById(R.id.btnCancelar);
        BD = new bdUsuario(this);

        btnRegistra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = Email.getText().toString();
                String pass = password.getText().toString();
                String repass = repetpass.getText().toString();

                if(user.equals("")|| pass.equals("")||repass.equals(""))
                    Toast.makeText(Registrar.this, "Por favor ingrese todo los capos", Toast.LENGTH_SHORT).show();
                else{
                    if(pass.equals(repass)){
                        Boolean verificarEmail = BD.ComprobarEmail(user);
                        if(verificarEmail==false){
                            Boolean insert = BD.insertData(user, pass);
                            if(insert==true){
                                Toast.makeText(Registrar.this, "Registro exitosamente", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                                startActivity(intent);
                            }else{
                                Toast.makeText(Registrar.this, "ERROR: en el registro", Toast.LENGTH_SHORT).show();
                            }
                        }else{
                            Toast.makeText(Registrar.this, "El usuario ya existe! por favor inica secion", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(Registrar.this, "Contraseña no coinciden", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }

}
